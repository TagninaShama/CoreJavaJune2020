import java.text.NumberFormat;
import java.util.Locale;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//creating an object
		PaymentCalculator obj = new PaymentCalculator();
		//calling methods from PaymentCalculator class
		obj.userInput();
		obj.header();
		obj.data();
		obj.footer();

	}
}
